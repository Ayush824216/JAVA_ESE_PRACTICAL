package com.example.expensecrud;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ExpensecrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExpensecrudApplication.class, args);
    }

    @Bean
    public CommandLineRunner printAppUrl() {
        return args -> {
            System.out.println("======================================");
            System.out.println("🚀 Expense CRUD Application Started!");
            System.out.println("🌐 Open in Browser:");
            System.out.println("👉 http://localhost:8088/index.html");
            System.out.println("======================================");
        };
    }
}
