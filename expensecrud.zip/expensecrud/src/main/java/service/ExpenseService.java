package com.example.expensecrud.service;

import com.example.expensecrud.model.Expense;
import com.example.expensecrud.repository.ExpenseRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseService {

    private final ExpenseRepository repo;

    public ExpenseService(ExpenseRepository repo) {
        this.repo = repo;
    }

    public List<Expense> getAllExpenses() {
        return repo.findAll();
    }

    public Expense addExpense(Expense e) {
        return repo.save(e);
    }

    public Expense updateExpense(Long id, Expense e) {
        Expense old = repo.findById(id).orElseThrow();
        old.setAmount(e.getAmount());
        old.setDescription(e.getDescription());
        return repo.save(old);
    }

    public void deleteExpense(Long id) {
        repo.deleteById(id);
    }
}
