package com.example.expensecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
